<?php
return array(
    'allow_robot'=>false,
	'allow_view'=>0,
    'about'=>array('name_en'=>'task')
);