<?php
$lang = array (
	'appname'=>'通讯录',
	'name' => '姓名',
	'weixin'=>'微信号',
	'frequent_tips'=>'没有常联系用户，点击用户可在右侧面板设置为常用',
	'relevant_user_found'=>'没有相关联系人',
	'all_personnel'=>'全部人员',
	'name_email_phone_enter'=>'可按姓名、邮箱、手机查询，按回车确认',
	'confirm_uninstall_app'=>'确定卸载应用',
	'operate_del_app'=>'此操作将删除应用',
	'delete_confirm_del'=>'内所有数据，请慎<br /><br />如果确实需要删除，请在下面输入 DELETE 字样确认删除',
	'registration_time'=>'注册时间',
	'usergroup'=>'用户组',
	'not_join_agency_department'=>'未加入机构或部门',
	'department'=>'所属部门',
	'unallocated_space'=>'未分配空间',
	'space_usage'=>'空间使用',
	'no_institution_users'=>'无机构用户',
	'frequently_contact'=>'常用联系人',
	'setFrequent'=>'设为常用联系人',
	'setFrequent_cancel'=>'取消常用联系人',
	'alluser'=>'全部人员',
	'empty'=>'空',
);

?>