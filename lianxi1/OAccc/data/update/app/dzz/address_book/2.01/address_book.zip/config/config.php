<?php
return array(
    'allow_robot'=>false,
	'allow_view'=>1,
    'about'=>array('name_en'=>'Contacts')
);