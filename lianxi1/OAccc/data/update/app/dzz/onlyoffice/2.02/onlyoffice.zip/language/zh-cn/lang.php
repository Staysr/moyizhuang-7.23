<?php
$lang = array
(
    'app_name'=>'文档编辑',
    'setting'=>'设置',
    'input_onlyoffice_url'=>'请输入OnlyOffice Document Server API地址',
    'input_onlyoffice_url_notice'=>'填写您的onlyoffice Document Server API地址，如:http://192.168.0.2/web-apps/apps/api/documents/api.js 或 http://192.168.0.2/OfficeWeb/apps/api/documents/api.js 根据你的文档服务器填写',
	'onlyoffice_enable_failed'=>'OnlyOffice Document Server API地址未设置',
    'onlyoffice_url_setfailed'=>'OnlyOffice Document Server API地址不能为空,更新失败'
);
?>	