<?php
return array(
    'allow_robot'=>false,
    'about'=>array('name_en'=>'Notes')
);