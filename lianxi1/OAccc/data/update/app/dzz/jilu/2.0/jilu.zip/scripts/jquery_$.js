function $(id) {
    return !id ? null : document.getElementById(id);
}