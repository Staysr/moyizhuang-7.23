<?php
$lang = array
(
    'app_name'=>'Zoho',
    'setting'=>'设置',
	'entryPointxoom'=>'申请地址',
	'entryPointxoom_ZohoAPIKey'=>'填写申请到的ZohoAPIKey',
	'input_ZohoAPIKey'=>'请输入ZohoAPIKey值',
	'your_file_extracted'=>'正在提取您的文件...',
	'internet_file_extracted'=>'正在从 Internet 上的主页中检索您的文件，请稍候',
	'ZohoAPIKey_cannot_install'=>'ZohoAPIKey 不合法，无法完成安装',
	'ZohoAPIKey_empty_cannot_install'=>'应用ZohoAPIKey为空，不能调用，请卸载重新安装',
	'unsupported_media_type'=>'不支持的格式',
	'zoho_enable_failed'=>'ZohoAPIKey未设置,启动失败',
    'zoho_key_setfailed'=>'ZohoAPIKey不合法,更新失败'
);
?>	