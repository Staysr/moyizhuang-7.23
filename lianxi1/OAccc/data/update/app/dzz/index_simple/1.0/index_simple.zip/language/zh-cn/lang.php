<?php
/*
 模板文件内调用方法
<div class="demo">{lang title}</div>
<div class="demo1">{lang dev_desc}</div>
*/
$lang = array (
	'appname'	=>'首页'
);

?>