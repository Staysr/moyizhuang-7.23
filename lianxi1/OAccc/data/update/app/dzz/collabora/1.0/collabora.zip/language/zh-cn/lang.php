<?php
$lang = array
(
    'app_name'=>'协同办公',
    'setting'=>'设置',
    'input_collabora_view_url'=>'请输入Collabora Online Server 地址',
    'input_collabora_view_url_notice'=>'填写您的Collabora Online Document Server 地址，如:http://192.168.0.2:9980/,http://collabora.example.com/(配置代理后) 根据你的文档服务器填写',
	'collaborae_view_enable_failed'=>'Collabora Online Server 地址未设置',
    'collabora_view_url_setfailed'=>'Collabora Online Server 地址不能为空'
);