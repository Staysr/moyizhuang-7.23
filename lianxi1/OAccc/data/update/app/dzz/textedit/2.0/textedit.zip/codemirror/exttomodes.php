<?php
$modes=array(
	'js'	=>'javascript',
	'php'	=>'php',
	'css'	=>'css',
	'htm'	=>'htmlmixed',
	'html'	=>'htmlmixed',
	'perl'  =>'perl',
	'py'	=>'python',
	'sql'	=>'sql',
	'vbs'	=>'vbscript',
	'c'		=>'clike',
	'h'		=>'clike',

);
?>