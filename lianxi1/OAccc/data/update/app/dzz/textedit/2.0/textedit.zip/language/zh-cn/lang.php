<?php
$lang = array (
	'save_new_version'=>'保存为新版本',
	'last_automatically_save_time'=>'最后一次自动保存时间',
	'current_contents_without_saving'=>'当前内容没有保存，确定要离开吗？',
	'confirm_del_file_release'=>'确定要删除文档的当前版本吗？',
	'del_file_release'=>'删除此版本',
	'use_release'=>'使用此版本',
	'use_release_failure'=>'使用此版本失败',
	'all_release'=>'所有版本',
	'download_plugin_look'=>'您的浏览器需要下载插件才能在线查看',
	'promptly_upload'=>'立即下载',
	'installation_complete'=>'插件安装完成后',
	'click_refresh'=>'点此刷新',
	'document_saved_success'=>'文档自动保存成功！',
	'unable_save_document'=>'无法保存文档，请确认您的网络连接正常后再次打开！',
	'are_retry_text'=>'正在重试',
	'use_release1'=>'使用版本',
	'document_not_exist'=>'文档不存在',
	'document_deleted_success'=>'文档删除成功',
	'error_saving_documents'=>'保存文档错误，请检查您的磁盘是否有足够空间或写入权限',
	'error_saving_documents1'=>'保存文档错误，请检查您数据库是否正常',
	'file_not_exist_or_deleted'=>'文件不存在或已删除！',
	'delete_version_failed'=>'删除版本失败',
);

?>