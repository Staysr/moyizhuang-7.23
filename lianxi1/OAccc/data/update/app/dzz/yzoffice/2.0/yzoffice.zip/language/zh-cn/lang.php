<?php
$lang = array (
	"error_try_again_later"			=>		"操作失败，请稍后重试!",
	"error_try_again"				=>		"打开失败，请重试!",
	"open_failed"					=>		"打开失败",
	"transmission_later"			=>		"转换中请稍后..",
	"data_transmission"				=>		"数据传输中，请稍候..",
	"success_opening"				=>		"操作成功，正在打开..",
	"file_not_existed"				=>		"文件不存在",
);

?>